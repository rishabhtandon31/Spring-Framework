package com.cg.mobilebilling.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	
	@Autowired
	 CustomerDAOServices customerDAOServices;
	@Autowired
	BillingDAOServices billingDAOServices;
	@Autowired
	 PlanDAOServices planDAOServices;
	@Autowired
	PostpaidAccountDAOServices postpaidAccountDAOServices;
	
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		return planDAOServices.findAll();
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode)
			throws BillingServicesDownException {
		Customer customer= new Customer(firstName, lastName, emailID, dateOfBirth, new Address(billingAddressPinCode, billingAddressCity, billingAddressState), null);
		customer=customerDAOServices.save(customer);
		return customer.getCustomerID();
	}
	
	@Override
	public long openPostpaidMobileAccount(int customerID, int planID, long mobileNo)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		try {
			Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->
			new CustomerDetailsNotFoundException("No customer details found"));
			Plan plan=planDAOServices.findById(planID).orElseThrow(()->
			new PlanDetailsNotFoundException("No plan details found with this Plan Id"));
			PostpaidAccount postpaidAccount= new PostpaidAccount(mobileNo, plan, null, customer);
			return (postpaidAccountDAOServices.save(postpaidAccount)).getMobileNo();
		} catch (CustomerDetailsNotFoundException | PlanDetailsNotFoundException  e) {
			throw e;
		}
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		try {
			System.out.println("hello");
			return customerDAOServices.findById(customerID).orElseThrow(()->
			new CustomerDetailsNotFoundException("Customer details not found"));
		} catch (CustomerDetailsNotFoundException e) {
			throw e;
		}
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAOServices.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer= customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		PostpaidAccount postpaidAccount =postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("No postpaid account found"));
		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		/*return postpaidAccountDAOServices.getCustomerAllPostpaidAccountsDetails(customerID);*/
		return null;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		//incomplete
		
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		//incomplete
		
		Customer customer= customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		PostpaidAccount postpaidAccount =postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("No postpaid account found"));
		
		
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer= customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		PostpaidAccount postpaidAccount =postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("No postpaid account found"));

		Plan plan=planDAOServices.findById(postpaidAccount.getPlan().getPlanID()).orElseThrow(()->
		new PlanDetailsNotFoundException("No plan is registered with this account"));
		
		plan=planDAOServices.findById(planID).orElseThrow(()->
		new PlanDetailsNotFoundException("Plan Id requested is not available"));
		postpaidAccount.setPlan(planDAOServices.findById(planID).get());
		postpaidAccountDAOServices.save(postpaidAccount);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer= customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		PostpaidAccount postpaidAccount =postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("No postpaid account found"));
		postpaidAccountDAOServices.deleteById(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Customer customer= customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		customerDAOServices.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer= customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("No customer details found"));
		PostpaidAccount postpaidAccount =postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("No postpaid account found"));
		return postpaidAccount.getPlan();
	}

}