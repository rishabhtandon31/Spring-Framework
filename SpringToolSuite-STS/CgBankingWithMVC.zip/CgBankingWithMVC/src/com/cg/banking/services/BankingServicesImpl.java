package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Component(value="bankingServices")
public class BankingServicesImpl implements BankingServices {
	static int pinNumberTry=0;
	
	@Autowired
	private AccountDAO accountDAO;
	@Autowired
	private TransactionDAO transactionDAO;
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
		try {
			if(!(account.getAccountType().equalsIgnoreCase("Savings") || account.getAccountType().equalsIgnoreCase("Current")))
				throw new InvalidAccountTypeException("Account type is not valid. Choose only Savings or Current");
			if(account.getAccountBalance() <1000)
				throw new InvalidAmountException("Balance should be more than 1000Rs. !!!");
			else{
				String status="Active";
				/*account= new Account(pinNumber, accountType, status, initBalance);*/
				account.setStatus(status);
				
				List<Transaction> transactions= new ArrayList<Transaction>();
				Transaction transaction= new Transaction(account.getAccountBalance(), "Deposit", account);
				transactions.add(transaction);
				account.setTransactions(transactions);
				account=accountDAO.save(account);
				if (account==null)
					throw new BankingServicesDownException("Servers ae down! try again after some time");
				return account;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Server is down. Please try again later");
		}
	}

	@Override
	public int depositAmount(int accountNo, int amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		try {
			Account account = accountDAO.findOne(accountNo);
			if(account == null) throw new AccountNotFoundException("Account details not found. Enter your account no. again");
			Transaction transaction= transactionDAO.save(new Transaction(amount, "Deposit", account));
			account.setAccountBalance((int) (account.getAccountBalance() + amount));
			account= accountDAO.save(account);
			if(account!=null)
				return account.getAccountBalance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	@Override
	public int withdrawAmount(int accountNo, int amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		try {
			Account account = accountDAO.findOne(accountNo);
			if(account == null) throw new AccountNotFoundException("Account details not found. Enter your account no. again");
			if(account.getStatus().equalsIgnoreCase("Locked")) throw new AccountBlockedException("Your Account Blocked!!");
			
			if(account.getPinNumber() != pinNumber) {
				System.out.println("heelooooooooooooo");
				throw new InvalidPinNumberException("Wrong Pin Number. Try again !!!");
			}
			Transaction transaction= transactionDAO.save(new Transaction(amount, "Withdraw", account));
			account.setAccountBalance(account.getAccountBalance() - amount);
			account= accountDAO.save(account);
			if(account!=null)
				return account.getAccountBalance();
			} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return 0;
	}
	
	@Override
	public int fundTransfer(int accountNoTo, int accountNoFrom, int transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		try {
			Account account;
			account = accountDAO.findOne(accountNoTo);
			if(account == null) throw new AccountNotFoundException("Wrong account number. Enter the recepient account number again!!!");
			account = accountDAO.findOne(accountNoFrom);
			if(account==null) throw new AccountNotFoundException("Wrong account number. Enter the your account number again!!!");
			int accountBalance=withdrawAmount(accountNoFrom, transferAmount, pinNumber);
			depositAmount(accountNoTo, transferAmount);
			return accountBalance;
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account;
		try {
			account = accountDAO.findOne(accountNo);
			if(account == null) throw new AccountNotFoundException("Account not found!!!");
			account.setTransactions(getAccountAllTransaction(accountNo));
			return account;
		} catch (Exception e) {
			e.printStackTrace();
			throw new AccountNotFoundException("Account not found!!!");
		}
	}
	

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		try{
			List<Account> accounts= accountDAO.findAll();
			return accounts;
		}catch (Exception e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Servers are down. Try gain after sometime.");
		}
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		try{
			List<Transaction> transactions= transactionDAO.findAll();
			if(transactions.isEmpty())
				throw new AccountNotFoundException("Account Not Found. Try again!!!");
			return transactions;
		}catch (Exception e) {
			e.printStackTrace();
			throw new BankingServicesDownException("Servers are down. Try gain after sometime.");
		}
	}
	
	@Override
	public String accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		try {
			Account account = accountDAO.findOne(accountNo);
			if(account==null) throw new AccountNotFoundException("Account Not Found. Please Try Again!!!");
			return account.getStatus();
		} catch (Exception e) {
			e.printStackTrace();
			throw new AccountNotFoundException("Account not found!!!");
		}
	}
	
	@Override
	public int accountDelete(int accountNo) throws BankingServicesDownException, AccountNotFoundException {
		accountDAO.delete(accountNo);
		transactionDAO.delete(accountNo);
		return 1;
	}

	@Override
	public boolean changeAccountPin(Account account)
			throws AccountNotFoundException, BankingServicesDownException {
		account=accountDAO.save(account);
		return true;
	}
	
	
}
